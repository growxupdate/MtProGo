// Package mtprogo provides a clean Go Telegram client foundation.
//
// V4 contains a real Bot API runtime and a pure Go MTProto probe. It does not
// import any external Telegram client library.
package mtprogo
