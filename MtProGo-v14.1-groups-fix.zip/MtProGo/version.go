package mtprogo

// Version is the current development version of MtProGo.
const Version = "v14.1.0-dev"
