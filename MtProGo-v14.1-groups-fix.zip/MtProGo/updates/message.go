package updates

import (
	"context"
	"time"
)

const (
	// ChatPrivate is a one-to-one user/bot chat.
	ChatPrivate = "private"
	// ChatGroup is a legacy basic group chat.
	ChatGroup = "group"
	// ChatSupergroup is a Telegram supergroup represented by MTProto PeerChannel.
	ChatSupergroup = "supergroup"
	// ChatChannel is a broadcast channel represented by MTProto PeerChannel.
	ChatChannel = "channel"
)

// ReplySender can send replies for a Message.
type ReplySender interface {
	Reply(ctx context.Context, chatID int64, replyToMessageID int, text string) error
}

// MessageEditor can edit text messages for a Message.
type MessageEditor interface {
	EditMessage(ctx context.Context, chatID int64, messageID int, text string) error
}

// MessageDeleter can delete messages for a Message.
type MessageDeleter interface {
	DeleteMessages(ctx context.Context, chatID int64, messageIDs ...int) error
}

// Message is a normalized Telegram message used by handlers.
type Message struct {
	ID       int
	ChatID   int64
	FromID   int64
	ChatType string
	Text     string
	Date     time.Time
	Raw      any

	ReplySender ReplySender
	Editor      MessageEditor
	Deleter     MessageDeleter
}

// Reply replies to this message using the configured ReplySender.
func (m *Message) Reply(ctx context.Context, text string) error {
	if m.ReplySender == nil {
		return ErrNoReplySender
	}
	return m.ReplySender.Reply(ctx, m.ChatID, m.ID, text)
}

// Edit edits this message using the configured MessageEditor.
func (m *Message) Edit(ctx context.Context, text string) error {
	if m.Editor == nil {
		return ErrNoReplySender
	}
	return m.Editor.EditMessage(ctx, m.ChatID, m.ID, text)
}

// Delete deletes this message using the configured MessageDeleter.
func (m *Message) Delete(ctx context.Context) error {
	if m.Deleter == nil {
		return ErrNoReplySender
	}
	return m.Deleter.DeleteMessages(ctx, m.ChatID, m.ID)
}
