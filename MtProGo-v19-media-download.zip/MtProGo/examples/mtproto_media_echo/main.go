package main

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	mtprogo "github.com/growxupdate/MtProGo"
	"github.com/growxupdate/MtProGo/filters"
	"github.com/growxupdate/MtProGo/updates"
)

func ask(label string) string {
	reader := bufio.NewReader(os.Stdin)
	fmt.Print(label)
	text, err := reader.ReadString('\n')
	if err != nil {
		panic(err)
	}
	return strings.TrimSpace(text)
}

func main() {
	fmt.Println("MtProGo V19 MTProto media echo")
	fmt.Println("Send a photo/document/video/audio/voice to the bot. It will download it to ./downloads and reply with the saved path.")
	fmt.Println()

	apiIDText := ask("Enter API ID: ")
	apiHash := ask("Enter API Hash: ")
	botToken := ask("Enter Bot Token: ")
	apiID64, err := strconv.ParseInt(apiIDText, 10, 32)
	if err != nil || apiID64 <= 0 {
		panic("invalid API ID")
	}

	bot := mtprogo.Must(mtprogo.NewMTProtoBot(
		mtprogo.MTProtoBotConfig{APIID: int(apiID64), APIHash: apiHash, Token: botToken, PollInterval: time.Second},
		mtprogo.WithSessionFile("bot.session"),
		mtprogo.WithMessageCacheCommands("start"),
		mtprogo.WithPeerCacheSize(2000),
		mtprogo.WithAutoReconnect(true),
		mtprogo.WithAutoFloodWait(true, 60*time.Second),
	))

	bot.OnMessage(filters.Command("start"), func(ctx context.Context, m *updates.Message) error {
		return m.Reply(ctx, "Send me any supported media. I will download it with pure MTProto.")
	})

	bot.OnMessage(filters.Media, func(ctx context.Context, m *updates.Message) error {
		path, err := m.Download(ctx, "downloads")
		if err != nil {
			return m.Reply(ctx, "Download failed: "+err.Error())
		}
		return m.Reply(ctx, fmt.Sprintf("Downloaded %s to %s", m.Media.Type, path))
	})

	mtprogo.Must0(bot.Run(context.Background()))
}
