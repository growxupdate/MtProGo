package filters

import (
	"testing"

	"github.com/growxupdate/MtProGo/updates"
)

func TestMediaFilters(t *testing.T) {
	msg := &updates.Message{Media: &updates.Media{Type: updates.MediaPhoto}}
	if !Media(msg) || !Photo(msg) {
		t.Fatal("photo media should match Media and Photo")
	}
	if Document(msg) || Video(msg) || Audio(msg) || Voice(msg) {
		t.Fatal("photo should not match document/video/audio/voice")
	}
	msg.Media.Type = updates.MediaVoice
	if !Voice(msg) || !Media(msg) {
		t.Fatal("voice should match Voice and Media")
	}
}
