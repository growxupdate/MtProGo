package mtprogo

// Version is the current development version of MtProGo.
const Version = "v19.0.0-dev"
