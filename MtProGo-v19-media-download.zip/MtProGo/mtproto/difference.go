package mtproto

import (
	"context"
	"encoding/binary"
	"fmt"
)

const (
	constructorUpdatesGetDifference    = 0x19c2f763
	constructorDifferenceEmpty         = 0x5d75a138
	constructorDifference              = 0x00f49ca0
	constructorDifferenceSlice         = 0xa8fb1981
	constructorDifferenceTooLong       = 0x4afe8f6d
	constructorMessageEmpty            = 0x90a6ca84
	constructorMessage                 = 0x9815cec8
	constructorPeerUser                = 0x59511722
	constructorPeerChat                = 0x36c6019a
	constructorPeerChannel             = 0xa2a5371e
	constructorMessageEntityBotCommand = 0x6cef8ac7
	constructorUpdateNewMessage        = 0x1f2b0afd
	constructorUpdateNewChannelMessage = 0x62ba04d9
)

const (
	MediaPhoto    = "photo"
	MediaDocument = "document"
	MediaVideo    = "video"
	MediaAudio    = "audio"
	MediaVoice    = "voice"
)

// DifferenceResult is a minimal parsed result of updates.getDifference.
type DifferenceResult struct {
	Constructor uint32
	State       *UpdatesState
	Messages    []TextMessage
	// Peers contains user/chat/channel references scanned from the difference body.
	Peers []PeerRef
	// Users is kept for backward compatibility and contains the same values as Peers.
	Users []PeerRef
	Raw   []byte
}

// TextMessage is a lightweight text message parsed from updates.Difference.
type TextMessage struct {
	ID       int32
	ChatID   int64
	FromID   int64
	ChatKind string
	FromKind string
	Date     int32
	Text     string
	Media    *MediaInfo
	Raw      []byte
}

// MediaInfo is a lightweight parsed Telegram media descriptor. It contains
// enough metadata to download common photos/documents and to expose high-level
// media filters while the full generated TL parser is still being built.
type MediaInfo struct {
	Type          string
	ID            int64
	AccessHash    int64
	FileReference []byte
	DCID          int32
	MIMEType      string
	FileName      string
	Size          int64
	ThumbSize     string
}

// UpdatesGetDifference calls updates.getDifference using the supplied state.
// It is a low-level polling primitive used by future high-level update loops.
func (c *EncryptedClient) UpdatesGetDifference(ctx context.Context, state UpdatesState, ptsLimit int32) (*DifferenceResult, *InvokeResult, error) {
	query := makeUpdatesGetDifferenceQuery(state, ptsLimit)
	result, err := c.Invoke(ctx, query)
	if err != nil {
		return nil, nil, err
	}
	diff, err := parseDifferenceResult(result.Body)
	if err != nil {
		return nil, result, err
	}
	result.Message = "updates.getDifference succeeded over encrypted MTProto"
	return diff, result, nil
}

func makeUpdatesGetDifferenceQuery(state UpdatesState, ptsLimit int32) []byte {
	var q tlBuffer
	q.putInt(constructorUpdatesGetDifference)
	flags := uint32(0)
	if ptsLimit > 0 {
		flags |= 1 << 1
	}
	q.putInt(flags)
	q.putInt(uint32(state.PTS))
	if ptsLimit > 0 {
		q.putInt(uint32(ptsLimit))
	}
	q.putInt(uint32(state.Date))
	q.putInt(uint32(state.QTS))
	return q.bytes()
}

func parseDifferenceResult(body []byte) (*DifferenceResult, error) {
	r := newTLReader(body)
	constructor, err := r.int()
	if err != nil {
		return nil, err
	}
	out := &DifferenceResult{Constructor: constructor, Raw: append([]byte(nil), body...)}
	out.Peers = scanPeerRefs(body)
	out.Users = out.Peers
	if scannedState := scanUpdatesState(body); scannedState != nil {
		out.State = scannedState
	}
	switch constructor {
	case constructorDifferenceEmpty:
		date, err := r.int()
		if err != nil {
			return nil, err
		}
		seq, err := r.int()
		if err != nil {
			return nil, err
		}
		out.State = &UpdatesState{Date: int32(date), Seq: int32(seq)}
		return out, nil
	case constructorDifferenceTooLong:
		pts, err := r.int()
		if err != nil {
			return nil, err
		}
		out.State = &UpdatesState{PTS: int32(pts)}
		return out, nil
	case constructorDifference, constructorDifferenceSlice:
		messages, err := parseMessageVector(r)
		if err != nil {
			// Keep the raw body available even if a future Message variant is not parsed yet.
			return out, nil
		}
		out.Messages = append(out.Messages, messages...)

		// updates.difference contains:
		//   new_messages:Vector<Message>
		//   new_encrypted_messages:Vector<EncryptedMessage>
		//   other_updates:Vector<Update>
		//   chats:Vector<Chat> users:Vector<User> state:updates.State
		// In private chats Telegram often puts new text messages in new_messages,
		// while supergroups/channels commonly arrive as updateNewChannelMessage in
		// other_updates. Parse that vector as well so handlers work in groups.
		if err := skipEncryptedMessageVector(r); err != nil {
			return out, nil
		}
		updateMessages, err := parseUpdateVector(r)
		if err != nil {
			return out, nil
		}
		out.Messages = append(out.Messages, updateMessages...)

		// V12+ scans the raw difference body for users/chats/channels access_hash and
		// final updates.state so the high-level loop can reply while the full TL
		// generated parser is still being built.
		return out, nil
	default:
		return nil, fmt.Errorf("mtproto: expected updates.Difference, got 0x%08x", constructor)
	}
}

func skipEncryptedMessageVector(r *tlReader) error {
	vector, err := r.int()
	if err != nil {
		return err
	}
	if vector != constructorVector {
		return fmt.Errorf("mtproto: expected encrypted messages vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return err
	}
	// Bot/user message update polling usually returns an empty encrypted-message
	// vector. A full encrypted chat parser is outside this lightweight runtime.
	if count != 0 {
		return fmt.Errorf("mtproto: encrypted message vector with %d items is not supported yet", count)
	}
	return nil
}

func parseUpdateVector(r *tlReader) ([]TextMessage, error) {
	vector, err := r.int()
	if err != nil {
		return nil, err
	}
	if vector != constructorVector {
		return nil, fmt.Errorf("mtproto: expected updates vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return nil, err
	}
	out := make([]TextMessage, 0, count)
	for i := 0; i < int(count); i++ {
		constructor, err := r.int()
		if err != nil {
			return out, err
		}
		switch constructor {
		case constructorUpdateNewMessage, constructorUpdateNewChannelMessage:
			start := r.off
			msg, ok, err := parseTextMessage(r)
			if err != nil {
				return out, err
			}
			if _, err := r.int(); err != nil { // pts
				return out, err
			}
			if _, err := r.int(); err != nil { // pts_count
				return out, err
			}
			if ok {
				msg.Raw = append([]byte(nil), r.buf[start:r.off]...)
				out = append(out, msg)
			}
		default:
			// This tiny parser only needs message updates for the high-level handler.
			// Unknown Update constructors cannot be safely skipped without full schema
			// generation, so stop parsing updates but keep messages parsed so far.
			return out, nil
		}
	}
	return out, nil
}

func parseMessageVector(r *tlReader) ([]TextMessage, error) {
	vector, err := r.int()
	if err != nil {
		return nil, err
	}
	if vector != constructorVector {
		return nil, fmt.Errorf("mtproto: expected vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return nil, err
	}
	out := make([]TextMessage, 0, count)
	for i := 0; i < int(count); i++ {
		start := r.off
		msg, ok, err := parseTextMessage(r)
		if err != nil {
			return out, err
		}
		if ok {
			msg.Raw = append([]byte(nil), r.buf[start:r.off]...)
			out = append(out, msg)
		}
	}
	return out, nil
}

func parseTextMessage(r *tlReader) (TextMessage, bool, error) {
	constructor, err := r.int()
	if err != nil {
		return TextMessage{}, false, err
	}
	switch constructor {
	case constructorMessageEmpty:
		flags, err := r.int()
		if err != nil {
			return TextMessage{}, false, err
		}
		if _, err := r.int(); err != nil {
			return TextMessage{}, false, err
		}
		if flags&1 != 0 {
			if _, err := parsePeer(r); err != nil {
				return TextMessage{}, false, err
			}
		}
		return TextMessage{}, false, nil
	case constructorMessage:
		flags, err := r.int()
		if err != nil {
			return TextMessage{}, false, err
		}
		flags2, err := r.int()
		if err != nil {
			return TextMessage{}, false, err
		}
		id, err := r.int()
		if err != nil {
			return TextMessage{}, false, err
		}
		var fromID int64
		var fromKind string
		if flags&(1<<8) != 0 {
			peer, err := parsePeer(r)
			if err != nil {
				return TextMessage{}, false, err
			}
			fromID = peer.ID
			fromKind = peer.Kind
		}
		if flags&(1<<29) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		chatPeer, err := parsePeer(r)
		if err != nil {
			return TextMessage{}, false, err
		}
		chatID := chatPeer.ID
		chatKind := chatPeer.Kind
		if flags&(1<<28) != 0 {
			if _, err := parsePeer(r); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<2) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: message fwd_from parsing not implemented")
		}
		if flags&(1<<11) != 0 {
			if _, err := r.long(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags2&1 != 0 {
			if _, err := r.long(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<3) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: reply_to parsing not implemented")
		}
		date, err := r.int()
		if err != nil {
			return TextMessage{}, false, err
		}
		text, err := r.string()
		if err != nil {
			return TextMessage{}, false, err
		}
		var media *MediaInfo
		if flags&(1<<9) != 0 {
			media, err = parseMessageMedia(r)
			if err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<6) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: reply_markup parsing not implemented")
		}
		if flags&(1<<7) != 0 {
			if err := skipMessageEntities(r); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<10) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<23) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: replies parsing not implemented")
		}
		if flags&(1<<15) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<16) != 0 {
			if _, err := r.string(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<17) != 0 {
			if _, err := r.long(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<20) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: reactions parsing not implemented")
		}
		if flags&(1<<22) != 0 {
			if err := skipRawVector(r); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<25) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags&(1<<30) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags2&(1<<2) != 0 {
			if _, err := r.long(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags2&(1<<3) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: factcheck parsing not implemented")
		}
		if flags2&(1<<5) != 0 {
			if _, err := r.int(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags2&(1<<6) != 0 {
			if _, err := r.long(); err != nil {
				return TextMessage{}, false, err
			}
		}
		if flags2&(1<<7) != 0 {
			return TextMessage{}, false, fmt.Errorf("mtproto: suggested_post parsing not implemented")
		}
		return TextMessage{ID: int32(id), ChatID: chatID, FromID: fromID, ChatKind: chatKind, FromKind: fromKind, Date: int32(date), Text: text, Media: media}, true, nil
	default:
		return TextMessage{}, false, fmt.Errorf("mtproto: unsupported Message constructor 0x%08x", constructor)
	}
}

const (
	constructorMessageMediaEmpty          = 0x3ded6320
	constructorMessageMediaPhoto          = 0x695150d7
	constructorMessageMediaDocument       = 0x52d8ccd9
	constructorPhotoEmpty                 = 0x2331b22d
	constructorPhoto                      = 0xfb197a65
	constructorDocumentEmpty              = 0x36f8c871
	constructorDocument                   = 0x8fd4c4d8
	constructorPhotoSizeEmpty             = 0x0e17e23c
	constructorPhotoSize                  = 0x75c78e60
	constructorPhotoCachedSize            = 0xe9a734fa
	constructorPhotoStrippedSize          = 0xe0b0bc2e
	constructorPhotoSizeProgressive       = 0xfa3efb95
	constructorPhotoPathSize              = 0xd8214d41
	constructorDocumentAttributeImageSize = 0x6c37c15c
	constructorDocumentAttributeAnimated  = 0x11b58939
	constructorDocumentAttributeAudio     = 0x9852f9c6
	constructorDocumentAttributeVideo     = 0x0ef02ce6
)

type parsedPhotoSize struct {
	Type string
	W    int32
	H    int32
	Size int32
}

func parseMessageMedia(r *tlReader) (*MediaInfo, error) {
	constructor, err := r.int()
	if err != nil {
		return nil, err
	}
	switch constructor {
	case constructorMessageMediaEmpty:
		return nil, nil
	case constructorMessageMediaPhoto:
		flags, err := r.int()
		if err != nil {
			return nil, err
		}
		var media *MediaInfo
		if flags&1 != 0 {
			media, err = parsePhoto(r)
			if err != nil {
				return nil, err
			}
		}
		if flags&(1<<2) != 0 {
			if _, err := r.int(); err != nil {
				return nil, err
			}
		}
		return media, nil
	case constructorMessageMediaDocument:
		flags, err := r.int()
		if err != nil {
			return nil, err
		}
		var media *MediaInfo
		if flags&1 != 0 {
			media, err = parseDocument(r)
			if err != nil {
				return nil, err
			}
		}
		if flags&(1<<5) != 0 {
			// alt_documents is uncommon for bot downloads; skip it when empty and fail
			// safely otherwise until full generated TL parsing lands.
			if err := skipDocumentVector(r); err != nil {
				return nil, err
			}
		}
		if flags&(1<<2) != 0 {
			if _, err := r.int(); err != nil {
				return nil, err
			}
		}
		return media, nil
	default:
		return nil, fmt.Errorf("mtproto: unsupported MessageMedia constructor 0x%08x", constructor)
	}
}

func parsePhoto(r *tlReader) (*MediaInfo, error) {
	constructor, err := r.int()
	if err != nil {
		return nil, err
	}
	switch constructor {
	case constructorPhotoEmpty:
		if _, err := r.long(); err != nil {
			return nil, err
		}
		return nil, nil
	case constructorPhoto:
		flags, err := r.int()
		if err != nil {
			return nil, err
		}
		id, err := r.long()
		if err != nil {
			return nil, err
		}
		accessHash, err := r.long()
		if err != nil {
			return nil, err
		}
		fileRef, err := r.bytes()
		if err != nil {
			return nil, err
		}
		if _, err := r.int(); err != nil { // date
			return nil, err
		}
		sizes, err := parsePhotoSizeVector(r)
		if err != nil {
			return nil, err
		}
		if flags&(1<<1) != 0 {
			if err := skipRawVector(r); err != nil {
				return nil, err
			}
		}
		dcID, err := r.int()
		if err != nil {
			return nil, err
		}
		chosen := choosePhotoSize(sizes)
		return &MediaInfo{Type: MediaPhoto, ID: int64(id), AccessHash: int64(accessHash), FileReference: fileRef, DCID: int32(dcID), ThumbSize: chosen.Type, Size: int64(chosen.Size), FileName: fmt.Sprintf("photo_%d.jpg", id)}, nil
	default:
		return nil, fmt.Errorf("mtproto: unsupported Photo constructor 0x%08x", constructor)
	}
}

func parseDocument(r *tlReader) (*MediaInfo, error) {
	constructor, err := r.int()
	if err != nil {
		return nil, err
	}
	switch constructor {
	case constructorDocumentEmpty:
		if _, err := r.long(); err != nil {
			return nil, err
		}
		return nil, nil
	case constructorDocument:
		flags, err := r.int()
		if err != nil {
			return nil, err
		}
		id, err := r.long()
		if err != nil {
			return nil, err
		}
		accessHash, err := r.long()
		if err != nil {
			return nil, err
		}
		fileRef, err := r.bytes()
		if err != nil {
			return nil, err
		}
		if _, err := r.int(); err != nil { // date
			return nil, err
		}
		mimeType, err := r.string()
		if err != nil {
			return nil, err
		}
		size, err := r.long()
		if err != nil {
			return nil, err
		}
		var thumbType string
		if flags&1 != 0 {
			sizes, err := parsePhotoSizeVector(r)
			if err != nil {
				return nil, err
			}
			thumbType = choosePhotoSize(sizes).Type
		}
		if flags&(1<<1) != 0 {
			if err := skipRawVector(r); err != nil {
				return nil, err
			}
		}
		dcID, err := r.int()
		if err != nil {
			return nil, err
		}
		attrs, err := parseDocumentAttributes(r)
		if err != nil {
			return nil, err
		}
		kind := MediaDocument
		if attrs.Voice {
			kind = MediaVoice
		} else if attrs.Video || hasPrefixASCII(mimeType, "video/") {
			kind = MediaVideo
		} else if hasPrefixASCII(mimeType, "audio/") {
			kind = MediaAudio
		}
		fileName := attrs.FileName
		if fileName == "" {
			fileName = defaultMediaFileName(kind, int64(id), mimeType)
		}
		return &MediaInfo{Type: kind, ID: int64(id), AccessHash: int64(accessHash), FileReference: fileRef, DCID: int32(dcID), MIMEType: mimeType, FileName: fileName, Size: int64(size), ThumbSize: thumbType}, nil
	default:
		return nil, fmt.Errorf("mtproto: unsupported Document constructor 0x%08x", constructor)
	}
}

func parsePhotoSizeVector(r *tlReader) ([]parsedPhotoSize, error) {
	vector, err := r.int()
	if err != nil {
		return nil, err
	}
	if vector != constructorVector {
		return nil, fmt.Errorf("mtproto: expected PhotoSize vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return nil, err
	}
	out := make([]parsedPhotoSize, 0, count)
	for i := 0; i < int(count); i++ {
		size, err := parsePhotoSize(r)
		if err != nil {
			return out, err
		}
		if size.Type != "" {
			out = append(out, size)
		}
	}
	return out, nil
}

func parsePhotoSize(r *tlReader) (parsedPhotoSize, error) {
	constructor, err := r.int()
	if err != nil {
		return parsedPhotoSize{}, err
	}
	switch constructor {
	case constructorPhotoSizeEmpty:
		t, err := r.string()
		return parsedPhotoSize{Type: t}, err
	case constructorPhotoSize:
		t, err := r.string()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		w, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		h, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		sz, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		return parsedPhotoSize{Type: t, W: int32(w), H: int32(h), Size: int32(sz)}, nil
	case constructorPhotoCachedSize:
		t, err := r.string()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		w, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		h, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		b, err := r.bytes()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		return parsedPhotoSize{Type: t, W: int32(w), H: int32(h), Size: int32(len(b))}, nil
	case constructorPhotoStrippedSize:
		t, err := r.string()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		b, err := r.bytes()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		return parsedPhotoSize{Type: t, Size: int32(len(b))}, nil
	case constructorPhotoSizeProgressive:
		t, err := r.string()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		w, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		h, err := r.int()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		sizes, err := readIntVector(r)
		if err != nil {
			return parsedPhotoSize{}, err
		}
		var max int32
		for _, v := range sizes {
			if v > max {
				max = v
			}
		}
		return parsedPhotoSize{Type: t, W: int32(w), H: int32(h), Size: max}, nil
	case constructorPhotoPathSize:
		t, err := r.string()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		b, err := r.bytes()
		if err != nil {
			return parsedPhotoSize{}, err
		}
		return parsedPhotoSize{Type: t, Size: int32(len(b))}, nil
	default:
		return parsedPhotoSize{}, fmt.Errorf("mtproto: unsupported PhotoSize constructor 0x%08x", constructor)
	}
}

func choosePhotoSize(sizes []parsedPhotoSize) parsedPhotoSize {
	if len(sizes) == 0 {
		return parsedPhotoSize{Type: "x"}
	}
	best := sizes[0]
	bestScore := int64(best.Size)
	if bestScore == 0 {
		bestScore = int64(best.W) * int64(best.H)
	}
	for _, s := range sizes[1:] {
		score := int64(s.Size)
		if score == 0 {
			score = int64(s.W) * int64(s.H)
		}
		if score > bestScore && s.Type != "" {
			best = s
			bestScore = score
		}
	}
	if best.Type == "" {
		best.Type = "x"
	}
	return best
}

type parsedDocumentAttributes struct {
	FileName string
	Video    bool
	Voice    bool
}

func parseDocumentAttributes(r *tlReader) (parsedDocumentAttributes, error) {
	vector, err := r.int()
	if err != nil {
		return parsedDocumentAttributes{}, err
	}
	if vector != constructorVector {
		return parsedDocumentAttributes{}, fmt.Errorf("mtproto: expected document attributes vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return parsedDocumentAttributes{}, err
	}
	var attrs parsedDocumentAttributes
	for i := 0; i < int(count); i++ {
		constructor, err := r.int()
		if err != nil {
			return attrs, err
		}
		switch constructor {
		case constructorDocumentAttributeFilename:
			name, err := r.string()
			if err != nil {
				return attrs, err
			}
			attrs.FileName = name
		case constructorDocumentAttributeImageSize:
			if _, err := r.int(); err != nil {
				return attrs, err
			}
			if _, err := r.int(); err != nil {
				return attrs, err
			}
		case constructorDocumentAttributeAnimated:
			// no fields
		case constructorDocumentAttributeAudio:
			flags, err := r.int()
			if err != nil {
				return attrs, err
			}
			if flags&(1<<10) != 0 {
				attrs.Voice = true
			}
			if _, err := r.int(); err != nil {
				return attrs, err
			} // duration
			if flags&1 != 0 {
				if _, err := r.string(); err != nil {
					return attrs, err
				}
			}
			if flags&(1<<1) != 0 {
				if _, err := r.string(); err != nil {
					return attrs, err
				}
			}
			if flags&(1<<2) != 0 {
				if _, err := r.bytes(); err != nil {
					return attrs, err
				}
			}
		case constructorDocumentAttributeVideo:
			attrs.Video = true
			flags, err := r.int()
			if err != nil {
				return attrs, err
			}
			if _, err := r.raw(8); err != nil {
				return attrs, err
			} // duration double
			if _, err := r.int(); err != nil {
				return attrs, err
			} // w
			if _, err := r.int(); err != nil {
				return attrs, err
			} // h
			if flags&(1<<2) != 0 {
				if _, err := r.int(); err != nil {
					return attrs, err
				}
			}
			if flags&(1<<4) != 0 {
				if _, err := r.raw(8); err != nil {
					return attrs, err
				}
			}
			if flags&(1<<5) != 0 {
				if _, err := r.string(); err != nil {
					return attrs, err
				}
			}
		default:
			return attrs, fmt.Errorf("mtproto: unsupported DocumentAttribute constructor 0x%08x", constructor)
		}
	}
	return attrs, nil
}

func readIntVector(r *tlReader) ([]int32, error) {
	vector, err := r.int()
	if err != nil {
		return nil, err
	}
	if vector != constructorVector {
		return nil, fmt.Errorf("mtproto: expected int vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return nil, err
	}
	out := make([]int32, 0, count)
	for i := 0; i < int(count); i++ {
		v, err := r.int()
		if err != nil {
			return out, err
		}
		out = append(out, int32(v))
	}
	return out, nil
}

func skipDocumentVector(r *tlReader) error {
	vector, err := r.int()
	if err != nil {
		return err
	}
	if vector != constructorVector {
		return fmt.Errorf("mtproto: expected document vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return err
	}
	for i := 0; i < int(count); i++ {
		if _, err := parseDocument(r); err != nil {
			return err
		}
	}
	return nil
}

func hasPrefixASCII(s, prefix string) bool {
	if len(s) < len(prefix) {
		return false
	}
	for i := range prefix {
		c := s[i]
		if c >= 'A' && c <= 'Z' {
			c += 'a' - 'A'
		}
		if c != prefix[i] {
			return false
		}
	}
	return true
}

func defaultMediaFileName(kind string, id int64, mimeType string) string {
	ext := ".bin"
	switch {
	case kind == MediaPhoto:
		ext = ".jpg"
	case kind == MediaVoice:
		ext = ".ogg"
	case kind == MediaAudio:
		ext = ".mp3"
	case kind == MediaVideo:
		ext = ".mp4"
	case mimeType == "application/pdf":
		ext = ".pdf"
	}
	return fmt.Sprintf("%s_%d%s", kind, id, ext)
}

type parsedPeer struct {
	ID   int64
	Kind string
}

func parsePeer(r *tlReader) (parsedPeer, error) {
	constructor, err := r.int()
	if err != nil {
		return parsedPeer{}, err
	}
	id, err := r.long()
	if err != nil {
		return parsedPeer{}, err
	}
	v := int64(id)
	switch constructor {
	case constructorPeerUser:
		return parsedPeer{ID: v, Kind: "user"}, nil
	case constructorPeerChat:
		return parsedPeer{ID: v, Kind: "chat"}, nil
	case constructorPeerChannel:
		return parsedPeer{ID: v, Kind: "channel"}, nil
	default:
		return parsedPeer{}, fmt.Errorf("mtproto: unsupported Peer constructor 0x%08x", constructor)
	}
}

func skipMessageEntities(r *tlReader) error {
	vector, err := r.int()
	if err != nil {
		return err
	}
	if vector != constructorVector {
		return fmt.Errorf("mtproto: expected entities vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return err
	}
	for i := 0; i < int(count); i++ {
		constructor, err := r.int()
		if err != nil {
			return err
		}
		switch constructor {
		case 0xbb92ba95, 0xfa04579d, 0x6f635b0d, constructorMessageEntityBotCommand, 0x6ed02538, 0x64e475c2, 0xbd610bc9, 0x826f8b60, 0x28a20571, 0x9b69e34b, 0x4c4e743f, 0x9c4e7e8b, 0xbf0693d4, 0x761e6af4, 0x32ca960f:
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
		case 0x73924be0: // pre: offset length language
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.string(); err != nil {
				return err
			}
		case 0x76a6d327: // textUrl
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.string(); err != nil {
				return err
			}
		case 0x352dca58: // mentionName
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.long(); err != nil {
				return err
			}
		case 0xc8cf05f8: // customEmoji
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.long(); err != nil {
				return err
			}
		case 0x20df5d0: // blockquote flags offset length
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
			if _, err := r.int(); err != nil {
				return err
			}
		default:
			return fmt.Errorf("mtproto: unsupported MessageEntity constructor 0x%08x", constructor)
		}
	}
	return nil
}

func skipRawVector(r *tlReader) error {
	vector, err := r.int()
	if err != nil {
		return err
	}
	if vector != constructorVector {
		return fmt.Errorf("mtproto: expected vector, got 0x%08x", vector)
	}
	count, err := r.int()
	if err != nil {
		return err
	}
	for i := 0; i < int(count); i++ {
		// Unknown object: this tiny parser cannot safely skip arbitrary TL objects.
		return fmt.Errorf("mtproto: raw vector with %d objects is not supported by the tiny V12 parser", count)
	}
	return nil
}

// encodeTestMessage is used by tests only.
func encodeTestMessage(id int32, fromID, chatID int64, text string) []byte {
	var b []byte
	b = binary.LittleEndian.AppendUint32(b, constructorMessage)
	b = binary.LittleEndian.AppendUint32(b, 1<<8|1<<7) // from_id + entities
	b = binary.LittleEndian.AppendUint32(b, 0)         // flags2
	b = binary.LittleEndian.AppendUint32(b, uint32(id))
	b = binary.LittleEndian.AppendUint32(b, constructorPeerUser)
	b = binary.LittleEndian.AppendUint64(b, uint64(fromID))
	b = binary.LittleEndian.AppendUint32(b, constructorPeerUser)
	b = binary.LittleEndian.AppendUint64(b, uint64(chatID))
	b = binary.LittleEndian.AppendUint32(b, 123) // date
	var tb tlBuffer
	tb.buf = b
	tb.putString(text)
	tb.putInt(constructorVector)
	tb.putInt(1)
	tb.putInt(constructorMessageEntityBotCommand)
	tb.putInt(0)
	tb.putInt(uint32(len(text)))
	return tb.bytes()
}
