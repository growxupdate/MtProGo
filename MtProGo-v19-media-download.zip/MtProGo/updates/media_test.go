package updates

import (
	"context"
	"errors"
	"testing"
)

type fakeDownloader struct{}

func (fakeDownloader) DownloadMessageMedia(ctx context.Context, msg *Message, dir string) (string, error) {
	if msg == nil || msg.Media == nil {
		return "", errors.New("missing media")
	}
	return dir + "/" + msg.Media.FileName, nil
}

func TestMessageDownload(t *testing.T) {
	m := &Message{Media: &Media{Type: MediaDocument, FileName: "a.txt"}, Downloader: fakeDownloader{}}
	path, err := m.Download(context.Background(), "downloads")
	if err != nil {
		t.Fatal(err)
	}
	if path != "downloads/a.txt" {
		t.Fatalf("unexpected path: %q", path)
	}
}
