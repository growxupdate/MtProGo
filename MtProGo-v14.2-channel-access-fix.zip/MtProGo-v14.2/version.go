package mtprogo

// Version is the current development version of MtProGo.
const Version = "v14.2.0-dev"
