# Changelog

## v12.0.0-dev

Added:

- Experimental pure MTProto bot updates loop using `updates.getState` + `updates.getDifference`
- `NewMTProtoBot` high-level runtime
- `MTProtoBotConfig` with poll interval and PTS limit
- Private text message dispatch from MTProto updates
- Pure MTProto `Message.Reply` for private users when `access_hash` is cached
- Raw peer/access_hash scanner for user peers in updates payloads
- Final `updates.state` scanner for difference state progression
- `examples/mtproto_bot_updates`

Kept:

- V11 selective cache policy
- V10 update/cache options
- V9 SRP 2FA login
- V8 account phone-code login
- V7.1 MTProto bot login + migration handling
- Bot API runtime for stable real bot polling

No external Telegram client libraries are used.
