package main

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	mtprogo "github.com/growxupdate/MtProGo"
	"github.com/growxupdate/MtProGo/filters"
	"github.com/growxupdate/MtProGo/updates"
)

func ask(label string) string {
	fmt.Print(label)
	r := bufio.NewReader(os.Stdin)
	v, err := r.ReadString('\n')
	if err != nil {
		panic(err)
	}
	return strings.TrimSpace(v)
}

func main() {
	fmt.Println("MtProGo V12 pure MTProto bot updates")
	apiIDText := ask("Enter API ID: ")
	apiHash := ask("Enter API Hash: ")
	botToken := ask("Enter Bot Token: ")

	apiID64, err := strconv.ParseInt(apiIDText, 10, 32)
	if err != nil || apiID64 <= 0 {
		panic("invalid API ID")
	}

	bot := mtprogo.Must(mtprogo.NewMTProtoBot(
		mtprogo.MTProtoBotConfig{
			APIID:        int(apiID64),
			APIHash:      apiHash,
			Token:        botToken,
			PollInterval: 2 * time.Second,
			PTSLimit:     100,
		},
		mtprogo.WithUpdates(true),
		mtprogo.WithMessageCacheSize(1000),
		mtprogo.WithPeerCacheSize(1000),
		mtprogo.WithMessageCacheCommands("start", "ping", "help"),
	))

	bot.OnMessage(filters.Command("start"), func(ctx context.Context, m *updates.Message) error {
		fmt.Printf("/start received from %d in chat %d\n", m.FromID, m.ChatID)
		return m.Reply(ctx, "Hello from MtProGo V12 over pure MTProto 🚀")
	})

	bot.OnMessage(filters.Command("ping"), func(ctx context.Context, m *updates.Message) error {
		return m.Reply(ctx, "pong")
	})

	bot.OnMessage(filters.Command("help"), func(ctx context.Context, m *updates.Message) error {
		return m.Reply(ctx, "Commands: /start, /ping, /help")
	})

	fmt.Println("Send /start or /ping to your bot in a private chat.")
	if err := bot.Run(context.Background()); err != nil {
		panic(err)
	}
}
