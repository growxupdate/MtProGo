package mtprogo

// Version is the current development version of MtProGo.
const Version = "v12.0.0-dev"
